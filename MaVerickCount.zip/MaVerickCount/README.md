![](https://github.com/vincentzhangz/MaVerickCount/workflows/Android%20CI/badge.svg)

# MaVerick Count

## Authors

* **Vincent** - [vincentzhangz](https://github.com/vincentzhangz)
* **Malvin Wikarsa** - [octa8888](https://github.com/octa8888)
